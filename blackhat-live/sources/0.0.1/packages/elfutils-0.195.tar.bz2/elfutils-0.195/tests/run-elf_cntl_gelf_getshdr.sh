#! /bin/sh
# Copyright (C) 2012 Red Hat, Inc.
# This file is part of elfutils.
#
# This file is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# elfutils is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

. $srcdir/test-subr.sh

tempfiles test_shdr.out

# However we open the elf file, the shdrs should be the same.
testrun ${abs_builddir}/test-elf_cntl_gelf_getshdr READ ${abs_builddir}/test-elf_cntl_gelf_getshdr \
  > test_shdr.out

testrun_compare ${abs_builddir}/test-elf_cntl_gelf_getshdr MMAP ${abs_builddir}/test-elf_cntl_gelf_getshdr \
  < test_shdr.out

testrun_compare ${abs_builddir}/test-elf_cntl_gelf_getshdr FDREAD ${abs_builddir}/test-elf_cntl_gelf_getshdr \
  < test_shdr.out
