char *HELLO = "hello";
